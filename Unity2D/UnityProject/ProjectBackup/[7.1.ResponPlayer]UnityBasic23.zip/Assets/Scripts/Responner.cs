﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Responner : MonoBehaviour
{
    public GameObject objPlayer;
    public string prefabName;

    public void ResponObject()
    {
        GameObject prefab =
            Resources.Load("Prefabs/" + prefabName) as GameObject;
        GameObject obj = Instantiate(prefab);
        obj.name = prefabName;
    }

    // Start is called before the first frame update
    void Start()
    {
        prefabName = objPlayer.name;
    }

    // Update is called once per frame
    void Update()
    {
        if(objPlayer == null)
        {
            ResponObject();
        }
    }
}
